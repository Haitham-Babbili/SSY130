## Synopsis

Reference code-base for SSY130 DSP-KIT lab. See user_guide.pdf for installation/use guidelines.