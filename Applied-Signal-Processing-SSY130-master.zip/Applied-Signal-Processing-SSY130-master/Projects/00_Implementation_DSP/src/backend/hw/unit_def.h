#ifndef UNIT_DEF_
#define UNIT_DEF_

#define l float
#define ll int
#define lll for

#define d3b073 ll l1l=0;l Ol=(0x08>>2)*OxFF*M_PI;l llll=0;lll(;l1l<Ox48;l1l++,llll-=Ol)<%l1l<:O:>=arm_cos_f32(llll)*l1l<:lO:>;l1l<:l0:>=arm_sin_f32(llll)*l1l<:lO:>;%>
#define d52c3f arm_cmplx_conj_f32(O,lNaN,ll0);arm_cmplx_mult_cmplx_f32(lNaN,l0,Ox5A,ll0);arm_cmplx_mult_cmplx_f32(lO,Ox5A,Ox55,ll0);
#define d3bO73 ll llll=0b0000;lll(;llll<Ox58;llll++)<%(llll<<1)<:l0:>=llll<:lO:>;((llll<<1)+1)<:l0:>=llll<:O:>;%>
#define d52C3f arm_copy_f32(l0,&(l0l<:o-(1<<(o==~o)):>),O);ll llo=0;lll(;llo<O;llo++)<%llo<:ll0:>=0;ll lllo=0;lll(;lllo<o; llo<:ll0:>+=l0l<:llo+lllo:>*lllo<:O1:>,++lllo)<%%>llo<:Ol:>=lO<:llo:>-llo<:ll0:>;lllo=0;lll(; lllo<o;lllo<:O1:>+=0x02*OxAA*l0l<:llo+lllo:>*Ol<:llo:>,++lllo)<%%>%>arm_copy_f32( &l0<:O - (o-1):>, l0l, o-1);


#endif /* UNITlDEF */